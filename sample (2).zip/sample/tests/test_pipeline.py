"""
Unit and integration tests for Screenshot Privacy Filter.
Tests regex detectors, bbox merging, redaction functions, and API endpoints.
"""

import pytest
import numpy as np
import cv2
from utils import calculate_iou, merge_overlapping_boxes, expand_bbox, bbox_from_points
from processor import PrivacyDetector
import re


class TestBboxOperations:
    """Test bounding box utility functions."""
    
    def test_calculate_iou_no_overlap(self):
        """Test IoU calculation with non-overlapping boxes."""
        box1 = (0, 0, 10, 10)
        box2 = (20, 20, 30, 30)
        assert calculate_iou(box1, box2) == 0.0
    
    def test_calculate_iou_complete_overlap(self):
        """Test IoU calculation with identical boxes."""
        box1 = (0, 0, 10, 10)
        box2 = (0, 0, 10, 10)
        assert calculate_iou(box1, box2) == 1.0
    
    def test_calculate_iou_partial_overlap(self):
        """Test IoU calculation with partial overlap."""
        box1 = (0, 0, 10, 10)
        box2 = (5, 5, 15, 15)
        iou = calculate_iou(box1, box2)
        assert 0.0 < iou < 1.0
        assert abs(iou - 0.142857) < 0.01  # Expected IoU for these boxes
    
    def test_merge_overlapping_boxes(self):
        """Test merging of overlapping bounding boxes."""
        boxes = [
            {'bbox': [0, 0, 10, 10], 'type': 'email', 'text': 'test1'},
            {'bbox': [5, 5, 15, 15], 'type': 'phone', 'text': 'test2'},
            {'bbox': [100, 100, 110, 110], 'type': 'face', 'text': ''}
        ]
        
        merged = merge_overlapping_boxes(boxes, iou_threshold=0.1, padding=5)
        
        # Should merge first two boxes, keep third separate
        assert len(merged) <= len(boxes)
        assert any('email' in box['type'] or 'phone' in box['type'] for box in merged)
    
    def test_expand_bbox(self):
        """Test bbox expansion with padding."""
        bbox = (10, 10, 20, 20)
        image_shape = (100, 100)
        expanded = expand_bbox(bbox, image_shape, padding=5)
        
        assert expanded[0] == 5  # x1 - 5
        assert expanded[1] == 5  # y1 - 5
        assert expanded[2] == 25  # x2 + 5
        assert expanded[3] == 25  # y2 + 5
    
    def test_expand_bbox_boundary(self):
        """Test bbox expansion at image boundaries."""
        bbox = (0, 0, 10, 10)
        image_shape = (100, 100)
        expanded = expand_bbox(bbox, image_shape, padding=5)
        
        # Should not go below 0
        assert expanded[0] >= 0
        assert expanded[1] >= 0
    
    def test_bbox_from_points(self):
        """Test creating bbox from points."""
        points = [(5, 10), (15, 10), (15, 20), (5, 20)]
        bbox = bbox_from_points(points)
        assert bbox == (5, 10, 15, 20)


class TestRegexDetectors:
    """Test regex pattern detection for sensitive data."""
    
    def test_email_detection(self):
        """Test email pattern matching."""
        pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
        
        valid_emails = [
            'test@example.com',
            'user.name+tag@domain.co.uk',
            'info@company.org'
        ]
        
        for email in valid_emails:
            assert pattern.search(email) is not None
    
    def test_phone_detection(self):
        """Test phone number pattern matching."""
        pattern = re.compile(r'(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}|\+?\d{10,15}')
        
        valid_phones = [
            '555-123-4567',
            '(555) 123-4567',
            '+1-555-123-4567',
            '5551234567',
            '+919876543210'
        ]
        
        for phone in valid_phones:
            assert pattern.search(phone) is not None
    
    def test_currency_detection(self):
        """Test currency amount pattern matching."""
        pattern = re.compile(r'(?:₹|Rs\.?|USD|\$|€|£)\s*[\d,]+(?:\.\d{2})?')
        
        valid_amounts = [
            '$100.00',
            '₹1,500',
            'Rs. 2500',
            'USD 1,000.00',
            '€50.99'
        ]
        
        for amount in valid_amounts:
            assert pattern.search(amount) is not None
    
    def test_credit_card_detection(self):
        """Test credit card pattern matching."""
        pattern = re.compile(r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b')
        
        valid_cards = [
            '1234 5678 9012 3456',
            '1234-5678-9012-3456',
            '1234567890123456'
        ]
        
        for card in valid_cards:
            assert pattern.search(card) is not None


class TestRedaction:
    """Test image redaction functions."""
    
    def test_pixelate_redaction(self):
        """Test pixelation redaction method."""
        # Create a test image
        image = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        
        detections = [
            {'bbox': [10, 10, 30, 30], 'type': 'test', 'confidence': 1.0}
        ]
        
        detector = PrivacyDetector(use_spacy=False, use_mtcnn=False)
        redacted = detector.redact_regions(image, detections, method='pixelate')
        
        # Redacted image should be different from original
        assert not np.array_equal(image, redacted)
        
        # Untouched areas should remain the same
        assert np.array_equal(image[0:5, 0:5], redacted[0:5, 0:5])
    
    def test_blur_redaction(self):
        """Test blur redaction method."""
        image = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        
        detections = [
            {'bbox': [10, 10, 30, 30], 'type': 'test', 'confidence': 1.0}
        ]
        
        detector = PrivacyDetector(use_spacy=False, use_mtcnn=False)
        redacted = detector.redact_regions(image, detections, method='blur')
        
        assert not np.array_equal(image, redacted)
    
    def test_black_redaction(self):
        """Test black box redaction method."""
        image = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        
        detections = [
            {'bbox': [10, 10, 30, 30], 'type': 'test', 'confidence': 1.0}
        ]
        
        detector = PrivacyDetector(use_spacy=False, use_mtcnn=False)
        redacted = detector.redact_regions(image, detections, method='black')
        
        # Check that the redacted region is black
        assert np.all(redacted[10:30, 10:30] == 0)


class TestDetector:
    """Test main PrivacyDetector class."""
    
    def test_detector_initialization(self):
        """Test detector initialization."""
        detector = PrivacyDetector(use_spacy=False, use_mtcnn=False)
        assert detector is not None
        assert detector.patterns is not None
    
    def test_ocr_detection(self):
        """Test OCR text detection."""
        # Create a simple test image with text
        image = np.ones((100, 300, 3), dtype=np.uint8) * 255
        cv2.putText(image, 'TEST TEXT', (10, 50), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        
        detector = PrivacyDetector(use_spacy=False, use_mtcnn=False)
        
        try:
            ocr_results = detector.detect_text_with_ocr(image)
            # Should detect some text (if pytesseract is available)
            assert isinstance(ocr_results, list)
        except Exception:
            # OCR might not be available in test environment
            pytest.skip("OCR not available")
    
    def test_process_image_empty(self):
        """Test processing an empty image."""
        image = np.ones((100, 100, 3), dtype=np.uint8) * 255
        
        detector = PrivacyDetector(use_spacy=False, use_mtcnn=False)
        redacted, detections = detector.process_image(
            image, 
            detection_config={'text': False, 'faces': False, 'qr_codes': False, 'ner': False}
        )
        
        assert redacted is not None
        assert isinstance(detections, list)


# Integration tests for API
@pytest.mark.asyncio
async def test_api_health():
    """Test health check endpoint."""
    from httpx import AsyncClient
    from app import app
    
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert 'status' in data
        assert data['status'] == 'healthy'


@pytest.mark.asyncio
async def test_api_redact_no_file():
    """Test redact endpoint without file."""
    from httpx import AsyncClient
    from app import app
    
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post("/api/redact")
        assert response.status_code == 422  # Unprocessable entity


@pytest.mark.asyncio
async def test_api_redact_with_image():
    """Test redact endpoint with valid image."""
    from httpx import AsyncClient
    from app import app
    import io
    
    # Create a test image
    test_image = np.ones((100, 100, 3), dtype=np.uint8) * 255
    is_success, buffer = cv2.imencode('.png', test_image)
    assert is_success
    
    async with AsyncClient(app=app, base_url="http://test") as client:
        files = {'file': ('test.png', io.BytesIO(buffer.tobytes()), 'image/png')}
        response = await client.post("/api/redact", files=files)
        
        assert response.status_code == 200
        data = response.json()
        assert 'success' in data
        assert 'detections' in data
        assert 'redacted_image' in data


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
