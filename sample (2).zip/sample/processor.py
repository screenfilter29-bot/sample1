"""
Main processing pipeline for Screenshot Privacy Filter.
Handles OCR, NER, face detection, QR detection, and redaction.
"""

import cv2
import numpy as np
import re
from typing import List, Dict, Any, Tuple, Optional
from PIL import Image
import logging
from utils import (
    merge_overlapping_boxes, 
    preprocess_image, 
    expand_bbox, 
    bbox_from_points,
    mask_sensitive_text
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PrivacyDetector:
    """Main class for detecting and redacting sensitive information in screenshots."""
    
    def __init__(self, use_spacy: bool = True, use_mtcnn: bool = True):
        """
        Initialize detector with optional heavy dependencies.
        
        Args:
            use_spacy: Whether to load spaCy for NER
            use_mtcnn: Whether to load MTCNN for face detection
        """
        self.use_spacy = use_spacy
        self.use_mtcnn = use_mtcnn
        
        # Initialize spaCy
        self.nlp = None
        if use_spacy:
            try:
                import spacy
                try:
                    self.nlp = spacy.load("en_core_web_sm")
                    logger.info("spaCy model loaded successfully")
                except OSError:
                    logger.warning("spaCy model not found. Run: python -m spacy download en_core_web_sm")
            except ImportError:
                logger.warning("spaCy not available, NER will be limited to regex")
        
        # Initialize face detector - force OpenCV cascade for reliability
        self.face_detector = None
        try:
            cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
            self.face_detector = cv2.CascadeClassifier(cascade_path)
            if self.face_detector.empty():
                logger.error(f"Failed to load cascade from: {cascade_path}")
            else:
                logger.info(f"OpenCV cascade classifier loaded from: {cascade_path}")
        except Exception as e:
            logger.error(f"Face detection unavailable: {e}")
        
        # Regex patterns for sensitive data - expanded to catch all IDs
        self.patterns = {
            'email': re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
            'phone': re.compile(r'(\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}|\+?\d{10,15}'),
            'currency': re.compile(r'(?:₹|Rs\.?|USD|\$|€|£)\s*[\d,]+(?:\.\d{2})?'),
            'amount': re.compile(r'\b\d{1,3}(?:,\d{3})*(?:\.\d{2})?\s*(?:USD|EUR|GBP|INR|Rs|₹)?\b'),
            'credit_card': re.compile(r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b'),
            'ssn': re.compile(r'\b\d{3}-\d{2}-\d{4}\b'),
            'transaction_id': re.compile(r'(?:Transaction\s+ID|TXN|TRANSACTION|TXN_ID|TX_ID|TRANS_ID)\s*[:\-]?\s*([A-Z0-9]{5,})', re.IGNORECASE),
            'generic_id': re.compile(r'\b(?:REF|ID|ORDER|INVOICE|INV|RECEIPT|REC|BOOKING|TICKET|CONF|CONFIRMATION|CUSTOMER|CUST|USER|ACCOUNT|ACC|ACCT|MEMBER|MEM|POLICY|POL|CLAIM|CASE|REQUEST|REQ|APPLICATION|APP|SERIAL|SN|SKU|UPC|TRACKING|TRACK|AWB|SHIPMENT|SHIP|PAYMENT|PAY|AUTH|APPROVAL|VOUCHER|COUPON|CODE|PIN|OTP|TOKEN|SESSION|BATCH|LOT|PO|PURCHASE|SALES|SO|DOC|DOCUMENT|FILE|RECORD|REG|REGISTRATION|LICENSE|LIC|PERMIT|CERT|CERTIFICATE|ENROLLMENT|ENROLL|SUBSCRIBER|SUB|CONTRACT|AGREEMENT|QUOTE|PROPOSAL|LEAD|OPPORTUNITY|DEAL|PROJECT|TASK|JOB|WORK|SERVICE|SVC|SUPPORT|HELP|ISSUE|BUG|ERROR|LOG|AUDIT|TRANSFER|WIRE|SWIFT|IBAN|ROUTING|RTN|ABA|CHECK|CHEQUE|DRAFT|BILL|STATEMENT|BALANCE|PAN|AADHAR|AADHAAR|PASSPORT|DL|DRIVING|VOTER|RATION|GST|GSTIN|TAN|CIN|DIN|FSSAI|UDYAM|MSME|IEC|EPF|UAN|ESI|PF|NPS|PRAN)[-:#\s]?\s*[A-Z0-9]{4,}\b', re.IGNORECASE),
            'alphanumeric_id': re.compile(r'\b[A-Z]{2,4}[-]?\d{6,}\b'),
            'numeric_id': re.compile(r'\b(?:No\.?|Number|#)\s*[:\-]?\s*\d{5,}\b', re.IGNORECASE),
            'uuid': re.compile(r'\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b'),
            'long_number': re.compile(r'\b\d{8,16}\b'),
            'name_pattern': re.compile(r'\b[A-Z][A-Z]+(?:\s+[A-Z])\b'),
        }
        
        # Context keywords that indicate nearby PII
        self.context_keywords = [
            'contact', 'phone', 'email', 'address', 'name', 'account',
            'balance', 'amount', 'payment', 'transaction', 'id', 'reference'
        ]
        
        # Common name prefixes/titles for regex-based name detection
        self.name_patterns = [
            re.compile(r'\b(?:Mr\.?|Mrs\.?|Ms\.?|Dr\.?|Prof\.?)\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b'),
            re.compile(r'\b(?:Name|Customer|User|Account\s*Holder|Beneficiary|Payee|Sender|Receiver|From|To)\s*[:\-]?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b', re.IGNORECASE),
            re.compile(r'\b[A-Z][A-Z]+\s+[A-Z](?:\s|$)'),
            re.compile(r'\b[A-Z][A-Za-z]+(?:\s+[A-Z][A-Za-z]*)+\b'),  # Capitalized names like GAVATHRI P
        ]
    
    def detect_text_with_ocr(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """
        Perform OCR to extract text and bounding boxes.
        Falls back to pytesseract if EasyOCR is not available.
        
        Args:
            image: Input image as numpy array
        
        Returns:
            List of detected text items with bboxes
        """
        detections = []
        
        try:
            import pytesseract
            from PIL import Image as PILImage
            
            # Convert to PIL for pytesseract
            pil_image = PILImage.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            
            # Get detailed data
            data = pytesseract.image_to_data(pil_image, output_type=pytesseract.Output.DICT)
            
            n_boxes = len(data['text'])
            logger.info(f"OCR processing {n_boxes} text boxes from pytesseract")
            
            for i in range(n_boxes):
                text = data['text'][i].strip()
                
                # Skip empty text
                if not text:
                    continue
                
                # Get confidence, handle -1 (no confidence) case
                try:
                    conf = int(data['conf'][i])
                except (ValueError, TypeError):
                    conf = 0
                
                # Use very low threshold to catch ALL text (even low confidence detections)
                # We want to detect everything, including faint/handwritten text
                if len(text) >= 1:
                    x, y, w, h = data['left'][i], data['top'][i], data['width'][i], data['height'][i]
                    
                    # Ensure valid bbox dimensions
                    if w > 0 and h > 0:
                        detections.append({
                            'type': 'text',
                            'text': text,
                            'bbox': [x, y, x + w, y + h],
                            'confidence': conf / 100.0 if conf > 0 else 0.5
                        })
                        logger.debug(f"OCR found: '{text[:20]}...' at bbox {[x, y, x+w, y+h]} conf={conf}")
            
            logger.info(f"OCR detected {len(detections)} valid text regions")
            if len(detections) == 0:
                logger.warning("OCR detected no text! Image may be too noisy or empty.")
            
        except Exception as e:
            logger.error(f"OCR failed: {e}", exc_info=True)
        
        return detections
    
    def detect_sensitive_patterns(self, ocr_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detect sensitive information using regex patterns.
        
        Args:
            ocr_results: List of OCR detections with text and bbox
        
        Returns:
            List of sensitive detections
        """
        sensitive_items = []
        
        if not ocr_results:
            logger.warning("Pattern detection: No OCR results to process")
            return sensitive_items
        
        logger.info(f"Pattern detection: Scanning {len(ocr_results)} OCR text items")
        
        # Build combined text for multi-word pattern matching
        combined_text = ' '.join([item['text'] for item in ocr_results])
        
        for item in ocr_results:
            text = item['text']
            matched = False
            
            # Check each pattern
            for pattern_name, pattern in self.patterns.items():
                if pattern.search(text):
                    masked_text = mask_sensitive_text(text)
                    sensitive_items.append({
                        'type': pattern_name,
                        'text': masked_text,
                        'bbox': item['bbox'],
                        'confidence': item.get('confidence', 0.8)
                    })
                    logger.info(f"Regex match: {pattern_name} pattern matched '{masked_text}' at bbox {item['bbox']}")
                    matched = True
                    break
            
            # If no pattern matched, check for name patterns
            if not matched:
                for name_pattern in self.name_patterns:
                    if name_pattern.search(text):
                        masked_text = mask_sensitive_text(text)
                        sensitive_items.append({
                            'type': 'name',
                            'text': masked_text,
                            'bbox': item['bbox'],
                            'confidence': 0.75
                        })
                        logger.info(f"Name pattern matched '{masked_text}' at bbox {item['bbox']}")
                        break
        
        logger.info(f"Pattern detection: Found {len(sensitive_items)} sensitive items")
        return sensitive_items
    
    def detect_entities_with_ner(self, ocr_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Detect named entities (names, locations) using spaCy NER.
        
        Args:
            ocr_results: List of OCR detections
        
        Returns:
            List of entity detections
        """
        if not self.nlp:
            return []
        
        entities = []
        
        if not ocr_results:
            logger.warning("NER: No OCR results to process")
            return entities
        
        # Build full text and character-to-box mapping simultaneously
        # This ensures exact alignment with how spaCy sees the text
        text_parts = []
        text_to_box_map = []
        char_pos = 0
        
        for idx, item in enumerate(ocr_results):
            text = item['text']
            
            # Record the exact character range for this OCR item
            start_pos = char_pos
            end_pos = char_pos + len(text)
            
            text_to_box_map.append({
                'start': start_pos,
                'end': end_pos,
                'bbox': item['bbox'],
                'text': text,
                'index': idx
            })
            
            text_parts.append(text)
            char_pos = end_pos
            
            # Add space separator (except after last item)
            if idx < len(ocr_results) - 1:
                text_parts.append(' ')
                char_pos += 1  # Account for the space
        
        # Reconstruct the exact text that spaCy will process
        full_text = ''.join(text_parts)
        logger.info(f"NER processing {len(ocr_results)} OCR items, text length: {len(full_text)}")
        logger.debug(f"NER text sample: {full_text[:100]}...")
        
        # Run spaCy NER
        doc = self.nlp(full_text)
        
        # Map entities back to OCR bboxes using precise character positions
        for ent in doc.ents:
            if ent.label_ in ['PERSON', 'GPE', 'LOC', 'ORG']:
                ent_start = ent.start_char
                ent_end = ent.end_char
                
                # Find all OCR boxes that overlap with this entity's character range
                # Use strict comparisons to handle boundary cases correctly
                # (ent.end_char is exclusive, so we need > and < not >= and <=)
                matched_boxes = []
                for box_map in text_to_box_map:
                    # Overlap if entity ends after box starts AND entity starts before box ends
                    if ent_end > box_map['start'] and ent_start < box_map['end']:
                        matched_boxes.append(box_map['bbox'])
                        logger.debug(f"NER '{ent.text}' [{ent_start}:{ent_end}] overlaps box '{box_map['text']}' [{box_map['start']}:{box_map['end']}]")
                
                if matched_boxes:
                    # Create detection for each matched box to handle multi-token entities
                    for bbox in matched_boxes:
                        entities.append({
                            'type': f'ner_{ent.label_.lower()}',
                            'text': mask_sensitive_text(ent.text) or '***',  # Fallback masking
                            'bbox': bbox,
                            'confidence': 0.7
                        })
                    logger.info(f"NER detected {ent.label_}: {mask_sensitive_text(ent.text) or '***'} ({len(matched_boxes)} boxes)")
                else:
                    logger.warning(f"NER entity '{ent.text}' [{ent_start}:{ent_end}] found no matching OCR boxes")
        
        logger.info(f"NER total: Found {len(entities)} entity detections")
        return entities
    
    def detect_faces(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """
        Detect faces in the image - BALANCED approach for speed and accuracy.
        
        Args:
            image: Input image as numpy array
        
        Returns:
            List of face detections with bboxes
        """
        faces = []
        
        try:
            if self.face_detector is None or self.face_detector.empty():
                logger.warning("Face detector not loaded")
                return faces
                
            # Convert to grayscale and apply histogram equalization
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            gray = cv2.equalizeHist(gray)
            
            # Only 3 balanced parameter combinations (instead of 32!)
            param_sets = [
                (1.03, 3, (10, 10)),     # Sensitive
                (1.1, 4, (20, 20)),      # Balanced
                (1.2, 5, (30, 30)),      # Conservative
            ]
            
            detected_set = set()
            
            for scale, neighbors, minsize in param_sets:
                try:
                    face_rects = self.face_detector.detectMultiScale(
                        gray, 
                        scaleFactor=scale, 
                        minNeighbors=neighbors, 
                        minSize=minsize
                    )
                    
                    logger.debug(f"Scale={scale}, neighbors={neighbors} -> Found {len(face_rects)} faces")
                    
                    for (x, y, w, h) in face_rects:
                        detected_set.add((int(x), int(y), int(w), int(h)))
                except Exception as e:
                    logger.debug(f"Error: {e}")
            
            logger.info(f"Total unique faces found: {len(detected_set)}")
            
            # Add faces to results with moderate expansion
            for (x, y, w, h) in detected_set:
                x = max(0, x - 10)
                y = max(0, y - 10)
                x2 = min(image.shape[1], x + w + 20)
                y2 = min(image.shape[0], y + h + 20)
                
                faces.append({
                    'type': 'face',
                    'text': '',
                    'bbox': [x, y, x2, y2],
                    'confidence': 0.9
                })
            
            logger.info(f"Total faces to redact: {len(faces)}")
            
        except Exception as e:
            logger.error(f"Face detection failed: {e}", exc_info=True)
        
        return faces
    
    def detect_qr_codes(self, image: np.ndarray) -> List[Dict[str, Any]]:
        """
        Detect QR codes and barcodes with enhanced preprocessing.
        
        Args:
            image: Input image as numpy array
        
        Returns:
            List of QR/barcode detections
        """
        codes = []
        
        try:
            from pyzbar.pyzbar import decode, ZBarSymbol
            
            # Try multiple preprocessing approaches for better detection
            images_to_try = [image]
            
            # Convert to grayscale
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                images_to_try.append(gray)
                
                # Increase contrast
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                enhanced = clahe.apply(gray)
                images_to_try.append(enhanced)
                
                # Binary threshold
                _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                images_to_try.append(binary)
                
                # Inverted binary
                inverted = cv2.bitwise_not(binary)
                images_to_try.append(inverted)
                
                # Adaptive threshold
                adaptive = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
                images_to_try.append(adaptive)
            
            seen_bboxes = set()
            
            for img in images_to_try:
                # Decode QR codes and barcodes
                decoded_objects = decode(img)
                
                for obj in decoded_objects:
                    # Get bounding box
                    points = obj.polygon
                    if len(points) == 4:
                        bbox = bbox_from_points([(p.x, p.y) for p in points])
                    else:
                        x, y, w, h = obj.rect
                        bbox = [x, y, x + w, y + h]
                    
                    # Avoid duplicate detections
                    bbox_key = tuple(bbox)
                    if bbox_key not in seen_bboxes:
                        seen_bboxes.add(bbox_key)
                        codes.append({
                            'type': f'qr_{obj.type.lower()}',
                            'text': '',
                            'bbox': bbox,
                            'confidence': 1.0
                        })
                
                if codes:
                    break
            
            logger.info(f"Detected {len(codes)} QR/barcodes")
            
        except Exception as e:
            logger.error(f"QR detection failed: {e}", exc_info=True)
        
        return codes
    
    def redact_regions(
        self, 
        image: np.ndarray, 
        detections: List[Dict[str, Any]], 
        method: str = 'pixelate',
        block_size: int = 10
    ) -> np.ndarray:
        """
        Redact detected regions using specified method.
        
        Args:
            image: Input image
            detections: List of detections with bboxes
            method: Redaction method ('pixelate', 'blur', 'black')
            block_size: Size of pixelation blocks
        
        Returns:
            Redacted image
        """
        redacted = image.copy()
        height, width = image.shape[:2]
        redacted_count = 0
        
        for detection in detections:
            bbox = detection['bbox']
            x1, y1, x2, y2 = [int(round(coord)) for coord in bbox]
            
            # Ensure coordinates are within image bounds
            x1 = max(0, min(x1, width - 1))
            y1 = max(0, min(y1, height - 1))
            x2 = max(x1 + 1, min(x2, width))
            y2 = max(y1 + 1, min(y2, height))
            
            # Skip if region is too small
            if x2 <= x1 or y2 <= y1:
                logger.warning(f"Skipping invalid bbox: {x1},{y1},{x2},{y2}")
                continue
            
            try:
                if method == 'pixelate':
                    # Extract region
                    region = redacted[y1:y2, x1:x2].copy()
                    h, w = region.shape[:2]
                    if h > 2 and w > 2:
                        # Shrink and expand for pixelation
                        temp = cv2.resize(region, (max(2, w // block_size), max(2, h // block_size)))
                        pixelated = cv2.resize(temp, (w, h), interpolation=cv2.INTER_NEAREST)
                        redacted[y1:y2, x1:x2] = pixelated
                        redacted_count += 1
                
                elif method == 'blur':
                    # Apply gaussian blur
                    region = redacted[y1:y2, x1:x2]
                    blurred = cv2.GaussianBlur(region, (51, 51), 0)
                    redacted[y1:y2, x1:x2] = blurred
                    redacted_count += 1
                
                else:  # black box
                    # Fill with black
                    redacted[y1:y2, x1:x2] = [0, 0, 0]
                    redacted_count += 1
                    
            except Exception as e:
                logger.error(f"Error redacting region {x1},{y1},{x2},{y2}: {e}")
                continue
        
        logger.info(f"Successfully redacted {redacted_count}/{len(detections)} regions using {method}")
        return redacted
    
    def process_image(
        self, 
        image: np.ndarray, 
        detection_config: Optional[Dict[str, bool]] = None,
        redaction_method: str = 'pixelate'
    ) -> Tuple[np.ndarray, List[Dict[str, Any]]]:
        """
        Main pipeline to process image and detect/redact sensitive information.
        
        Args:
            image: Input image as numpy array
            detection_config: Dict specifying which detections to run
            redaction_method: Method for redaction
        
        Returns:
            Tuple of (redacted_image, list of detections)
        """
        if detection_config is None:
            detection_config = {
                'text': True,
                'faces': True,
                'qr_codes': True,
                'ner': True
            }
        
        # Preprocess
        processed = preprocess_image(image)
        
        all_detections = []
        ocr_results = None
        
        # OCR - extract text for pattern matching
        # Always run OCR if text or NER detection is requested
        if detection_config.get('text', False) or detection_config.get('ner', False):
            ocr_results = self.detect_text_with_ocr(processed)
        
        # Pattern-based sensitive text detection (emails, phones, amounts, transaction IDs)
        if detection_config.get('text', False) and ocr_results:
            sensitive_patterns = self.detect_sensitive_patterns(ocr_results)
            all_detections.extend(sensitive_patterns)
        
        # NER-based detection (names, locations, organizations)
        if detection_config.get('ner', False) and ocr_results:
            entities = self.detect_entities_with_ner(ocr_results)
            all_detections.extend(entities)
        
        # Face detection
        if detection_config.get('faces', True):
            faces = self.detect_faces(processed)
            all_detections.extend(faces)
        
        # QR code detection
        if detection_config.get('qr_codes', True):
            qr_codes = self.detect_qr_codes(processed)
            all_detections.extend(qr_codes)
        
        # Merge overlapping detections
        merged_detections = merge_overlapping_boxes(all_detections)
        
        # Redact
        redacted_image = self.redact_regions(processed, merged_detections, method=redaction_method)
        
        logger.info(f"Processing complete: {len(merged_detections)} regions redacted")
        
        return redacted_image, merged_detections
