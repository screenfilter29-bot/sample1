# Screenshot Privacy Filter - Replit Project

## Overview
A privacy-focused web application that detects and redacts sensitive information (PII, faces, QR codes) from screenshots using OCR, NER, and computer vision.

## Project Status
**Created**: November 15, 2025
**Last Updated**: December 16, 2025
**Status**: MVP Complete and Running
**Framework**: FastAPI + Vanilla JavaScript

## Architecture
- **Backend**: FastAPI (Python 3.11) with uvicorn
- **Detection Pipeline**: 
  - OCR: pytesseract
  - NER: spaCy (en_core_web_sm)
  - Face Detection: OpenCV Haar Cascade
  - QR Detection: pyzbar
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Image Processing**: OpenCV, Pillow

## Key Features
1. Multi-layer detection (text, faces, QR codes, NER)
2. Three redaction methods (pixelate, blur, black box)
3. Interactive web UI with before/after preview
4. Privacy-first: no permanent storage
5. Comprehensive test suite

## File Structure
- `app.py` - FastAPI server
- `processor.py` - Detection pipeline
- `utils.py` - Helper functions
- `static/` - Frontend files
- `tests/` - Test suite
- `sample_data/` - Synthetic test data

## Running the Project
The project runs via the Web Server workflow on port 5000.

## System Dependencies
- tesseract (OCR engine)
- zbar (QR code detection)

## Recent Changes
- December 16, 2025: Configured for Replit environment
- Removed TensorFlow/MTCNN to reduce disk usage (using OpenCV cascade for face detection)
- Installed spaCy model en_core_web_sm

## User Preferences
None specified yet.
