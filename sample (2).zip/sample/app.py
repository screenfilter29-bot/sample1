"""
FastAPI server for Screenshot Privacy Filter.
Provides REST API endpoints for uploading and redacting screenshots.
"""

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
import cv2
import numpy as np
from PIL import Image
import io
import os
import tempfile
import logging
from typing import Optional
from processor import PrivacyDetector

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Screenshot Privacy Filter",
    description="Detect and redact sensitive information from screenshots",
    version="1.0.0"
)

# CORS middleware for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
os.makedirs("static", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Initialize detector (use OpenCV cascade for face detection, no TensorFlow)
detector = PrivacyDetector(use_spacy=True, use_mtcnn=False)

# File size limit (5 MB)
MAX_FILE_SIZE = 5 * 1024 * 1024


@app.get("/")
async def read_root():
    """Serve the main HTML page."""
    import os
    html_path = os.path.join(os.path.dirname(__file__), "static", "index.html")
    return FileResponse(html_path)


@app.post("/api/redact")
async def redact_screenshot(
    file: UploadFile = File(...),
    detect_text: Optional[str] = Form("true"),
    detect_faces: Optional[str] = Form("true"),
    detect_qr: Optional[str] = Form("true"),
    detect_ner: Optional[str] = Form("true"),
    redaction_method: Optional[str] = Form("pixelate"),
    return_image: Optional[str] = Form("false")
):
    """
    Main endpoint to redact sensitive information from screenshots.
    
    Args:
        file: Screenshot file (multipart/form-data)
        detect_text: Whether to detect sensitive text patterns
        detect_faces: Whether to detect faces
        detect_qr: Whether to detect QR codes
        detect_ner: Whether to use NER for entities
        redaction_method: Method for redaction (pixelate, blur, black)
        return_image: Whether to return the image binary
    
    Returns:
        JSON with detections and image data, or binary image
    """
    try:
        # Read file
        contents = await file.read()
        
        # Check file size
        if len(contents) > MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail="File too large (max 5 MB)")
        
        # Try to decode with OpenCV first
        nparr = np.frombuffer(contents, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        
        # If OpenCV fails, try with PIL for more formats
        if image is None:
            try:
                pil_image = Image.open(io.BytesIO(contents))
                # Convert to RGB if needed (handles RGBA, P, L modes)
                if pil_image.mode in ('RGBA', 'LA', 'P'):
                    background = Image.new('RGB', pil_image.size, (255, 255, 255))
                    if pil_image.mode == 'P':
                        pil_image = pil_image.convert('RGBA')
                    background.paste(pil_image, mask=pil_image.split()[-1] if pil_image.mode == 'RGBA' else None)
                    pil_image = background
                elif pil_image.mode != 'RGB':
                    pil_image = pil_image.convert('RGB')
                
                # Convert PIL to OpenCV format
                image = cv2.cvtColor(np.array(pil_image), cv2.COLOR_RGB2BGR)
            except Exception as e:
                logger.error(f"Failed to open image with PIL: {e}")
                raise HTTPException(status_code=400, detail="Invalid or unsupported image format")
        
        if image is None:
            raise HTTPException(status_code=400, detail="Invalid image file")
        
        # Parse detection config
        detection_config = {
            'text': (detect_text or 'true').lower() == 'true',
            'faces': (detect_faces or 'true').lower() == 'true',
            'qr_codes': (detect_qr or 'true').lower() == 'true',
            'ner': (detect_ner or 'true').lower() == 'true'
        }
        
        logger.info(f"Processing image with config: {detection_config}")
        
        # Process image
        redacted_image, detections = detector.process_image(
            image, 
            detection_config=detection_config,
            redaction_method=redaction_method or 'pixelate'
        )
        
        # Encode redacted image
        is_success, buffer = cv2.imencode('.png', redacted_image)
        if not is_success:
            raise HTTPException(status_code=500, detail="Failed to encode redacted image")
        
        io_buf = io.BytesIO(buffer)
        
        # Return based on request
        if (return_image or 'false').lower() == 'true':
            return StreamingResponse(io_buf, media_type="image/png")
        else:
            # Return JSON with base64 image
            import base64
            image_base64 = base64.b64encode(buffer).decode('utf-8')
            
            # Sanitize detections for response (don't send full sensitive text)
            safe_detections = []
            for det in detections:
                safe_detections.append({
                    'type': det['type'],
                    'bbox': det['bbox'],
                    'confidence': det.get('confidence', 1.0)
                })
            
            return JSONResponse({
                'success': True,
                'detections': safe_detections,
                'num_detections': len(safe_detections),
                'redacted_image': f"data:image/png;base64,{image_base64}"
            })
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing image: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        'status': 'healthy',
        'detector_loaded': detector is not None,
        'spacy_available': detector.nlp is not None,
        'face_detector_available': detector.face_detector is not None
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=5000)
