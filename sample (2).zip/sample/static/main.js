let selectedFiles = [];
let processedResults = [];
let originalImagesData = [];

const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const processBtn = document.getElementById('processBtn');
const previewSection = document.getElementById('previewSection');
const originalImage = document.getElementById('originalImage');
const redactedImage = document.getElementById('redactedImage');
const loadingOverlay = document.getElementById('loadingOverlay');
const detectionCount = document.getElementById('detectionCount');
const processingTime = document.getElementById('processingTime');
const detectionsContent = document.getElementById('detectionsContent');
const downloadBtn = document.getElementById('downloadBtn');
const downloadAllBtn = document.getElementById('downloadAllBtn');
const resetBtn = document.getElementById('resetBtn');
const fileList = document.getElementById('fileList');

const detectText = document.getElementById('detectText');
const detectFaces = document.getElementById('detectFaces');
const detectQR = document.getElementById('detectQR');
const detectNER = document.getElementById('detectNER');
const redactionMethod = document.getElementById('redactionMethod');

let currentImageIndex = 0;

uploadArea.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', handleFileSelect);
processBtn.addEventListener('click', processImages);
downloadBtn.addEventListener('click', downloadCurrentImage);
downloadAllBtn.addEventListener('click', downloadAllImages);
resetBtn.addEventListener('click', resetApp);

uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadArea.classList.add('drag-over');
});

uploadArea.addEventListener('dragleave', () => {
    uploadArea.classList.remove('drag-over');
});

uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadArea.classList.remove('drag-over');
    
    const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
    if (files.length > 0) {
        handleFiles(files);
    }
});

function handleFileSelect(e) {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
        handleFiles(files);
    }
}

function handleFiles(files) {
    const maxSize = 5 * 1024 * 1024;
    const validFiles = [];
    const errors = [];
    
    for (const file of files) {
        if (!file.type.startsWith('image/')) {
            errors.push(`${file.name}: Not an image file`);
            continue;
        }
        if (file.size > maxSize) {
            errors.push(`${file.name}: Exceeds 5 MB limit`);
            continue;
        }
        validFiles.push(file);
    }
    
    if (errors.length > 0) {
        alert('Some files were skipped:\n' + errors.join('\n'));
    }
    
    if (validFiles.length === 0) {
        return;
    }
    
    selectedFiles = validFiles;
    originalImagesData = [];
    processedResults = [];
    currentImageIndex = 0;
    
    validFiles.forEach((file, index) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            originalImagesData[index] = e.target.result;
            if (index === 0) {
                originalImage.src = e.target.result;
            }
        };
        reader.readAsDataURL(file);
    });

    processBtn.disabled = false;
    
    const uploadContent = uploadArea.querySelector('.upload-content');
    if (validFiles.length === 1) {
        uploadContent.innerHTML = `
            <svg class="upload-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3>${validFiles[0].name}</h3>
            <p class="file-info">Click to select different files</p>
        `;
    } else {
        uploadContent.innerHTML = `
            <svg class="upload-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3>${validFiles.length} images selected</h3>
            <p class="file-info">Click to select different files</p>
        `;
    }
    
    updateFileList();
}

function updateFileList() {
    if (selectedFiles.length <= 1) {
        fileList.style.display = 'none';
        return;
    }
    
    fileList.style.display = 'block';
    fileList.innerHTML = '<h4>Selected Files:</h4>' + 
        selectedFiles.map((f, i) => 
            `<div class="file-item ${i === currentImageIndex ? 'active' : ''}" data-index="${i}">
                <span class="file-name">${f.name}</span>
                <span class="file-status" id="status-${i}">Pending</span>
            </div>`
        ).join('');
    
    fileList.querySelectorAll('.file-item').forEach(item => {
        item.addEventListener('click', () => {
            const index = parseInt(item.dataset.index);
            showImage(index);
        });
    });
}

function showImage(index) {
    currentImageIndex = index;
    
    if (originalImagesData[index]) {
        originalImage.src = originalImagesData[index];
    }
    
    if (processedResults[index]) {
        redactedImage.src = processedResults[index].redacted_image;
        detectionCount.textContent = processedResults[index].num_detections;
        displayDetections(processedResults[index].detections);
    } else {
        redactedImage.src = '';
    }
    
    document.querySelectorAll('.file-item').forEach((item, i) => {
        item.classList.toggle('active', i === index);
    });
}

async function processImages() {
    if (selectedFiles.length === 0) return;

    const startTime = performance.now();
    
    previewSection.style.display = 'block';
    loadingOverlay.style.display = 'flex';
    redactedImage.src = '';
    processedResults = [];

    previewSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

    let totalDetections = 0;
    
    try {
        for (let i = 0; i < selectedFiles.length; i++) {
            const file = selectedFiles[i];
            const statusEl = document.getElementById(`status-${i}`);
            if (statusEl) statusEl.textContent = 'Processing...';
            
            const formData = new FormData();
            formData.append('file', file);
            formData.append('detect_text', detectText.checked);
            formData.append('detect_faces', detectFaces.checked);
            formData.append('detect_qr', detectQR.checked);
            formData.append('detect_ner', detectNER.checked);
            formData.append('redaction_method', redactionMethod.value);
            formData.append('return_image', 'false');

            const response = await fetch('/api/redact', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(`${file.name}: ${error.detail || 'Processing failed'}`);
            }

            const result = await response.json();
            result.fileName = file.name;
            processedResults[i] = result;
            totalDetections += result.num_detections;
            
            if (statusEl) statusEl.textContent = `Done (${result.num_detections} found)`;
            
            if (i === 0) {
                redactedImage.src = result.redacted_image;
                displayDetections(result.detections);
            }
        }
        
        const endTime = performance.now();
        const duration = ((endTime - startTime) / 1000).toFixed(2);

        detectionCount.textContent = totalDetections;
        processingTime.textContent = `${duration}s`;

        loadingOverlay.style.display = 'none';
        
        if (selectedFiles.length > 1) {
            downloadAllBtn.style.display = 'inline-block';
        }

    } catch (error) {
        console.error('Error processing images:', error);
        alert(`Error: ${error.message}`);
        loadingOverlay.style.display = 'none';
    }
}

function displayDetections(detections) {
    detectionsContent.innerHTML = '';

    if (detections.length === 0) {
        detectionsContent.innerHTML = '<p style="color: #10b981; font-weight: 600;">No sensitive information detected!</p>';
        return;
    }

    const grouped = {};
    detections.forEach(det => {
        const type = det.type;
        if (!grouped[type]) {
            grouped[type] = [];
        }
        grouped[type].push(det);
    });

    Object.entries(grouped).forEach(([type, items]) => {
        const badge = document.createElement('div');
        badge.className = 'detection-badge';
        badge.innerHTML = `
            <span class="detection-type">${formatDetectionType(type)}</span>
            <span class="detection-confidence">${items.length}</span>
        `;
        detectionsContent.appendChild(badge);
    });
}

function formatDetectionType(type) {
    const typeMap = {
        'email': 'Email',
        'phone': 'Phone',
        'currency': 'Currency',
        'amount': 'Amount',
        'credit_card': 'Credit Card',
        'ssn': 'SSN',
        'transaction_id': 'Transaction ID',
        'generic_id': 'ID/Reference',
        'alphanumeric_id': 'Alphanumeric ID',
        'numeric_id': 'Numeric ID',
        'uuid': 'UUID',
        'long_number': 'Long Number',
        'name': 'Name',
        'face': 'Face',
        'qr_qrcode': 'QR Code',
        'qr_code128': 'Barcode',
        'qr_ean13': 'Barcode (EAN)',
        'qr_ean8': 'Barcode (EAN-8)',
        'qr_upca': 'Barcode (UPC-A)',
        'qr_upce': 'Barcode (UPC-E)',
        'qr_code39': 'Barcode (Code 39)',
        'qr_i25': 'Barcode (I2/5)',
        'ner_person': 'Person Name',
        'ner_gpe': 'Location',
        'ner_loc': 'Location',
        'ner_org': 'Organization'
    };

    return typeMap[type] || type.replace('_', ' ').replace('qr ', '').toUpperCase();
}

function downloadCurrentImage() {
    if (!redactedImage.src || processedResults.length === 0) return;
    
    const result = processedResults[currentImageIndex];
    if (!result) return;

    const link = document.createElement('a');
    link.href = result.redacted_image;
    const originalName = result.fileName || selectedFiles[currentImageIndex]?.name || 'image';
    link.download = `redacted_${originalName.split('.')[0]}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

async function downloadAllImages() {
    if (processedResults.length === 0) return;
    
    if (processedResults.length === 1) {
        downloadCurrentImage();
        return;
    }
    
    for (let i = 0; i < processedResults.length; i++) {
        const result = processedResults[i];
        if (!result) continue;
        
        const link = document.createElement('a');
        link.href = result.redacted_image;
        const originalName = result.fileName || `image_${i + 1}`;
        link.download = `redacted_${originalName.split('.')[0]}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        await new Promise(resolve => setTimeout(resolve, 300));
    }
}

function resetApp() {
    selectedFiles = [];
    originalImagesData = [];
    processedResults = [];
    currentImageIndex = 0;
    fileInput.value = '';
    processBtn.disabled = true;
    previewSection.style.display = 'none';
    fileList.style.display = 'none';
    downloadAllBtn.style.display = 'none';
    
    const uploadContent = uploadArea.querySelector('.upload-content');
    uploadContent.innerHTML = `
        <svg class="upload-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                  d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
        <h3>Drop screenshots here or click to upload</h3>
        <p class="file-info">Support bulk upload - Select multiple images (JPG, PNG, GIF, BMP, WebP, TIFF)</p>
        <p class="file-info">Maximum 5 MB per file</p>
    `;

    window.scrollTo({ top: 0, behavior: 'smooth' });
}
